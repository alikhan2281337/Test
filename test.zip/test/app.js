

// const text = "Привет1"
// function Test(str) {
//     const regExp = /\d/
    
//     let hasDigit = regExp.test(str)
//     if(hasDigit){
//         console.log(`Данный текст "${str}" содержит цифры`);
//     }
//     else{
//         console.log(`${str} тут нет цифр`);
//     }
// }
// Test(text)


// let i = 0
// let second = () => {
//     i++
    
//     if(i >= 10){
//         clearInterval(interval)
//         push()
//     }
//     console.log(`Прошло ${i} секунд`);
    
// }

// let interval = setInterval(second, 1000)  

// let j = 1
// let push = () => {
//     if(j <= 10){
//         console.log(j);
//         j++
//     }
//     else{
//         clearInterval(inter)
//     }
// }
// let inter = setInterval(push, 1000)

// const button = document.querySelector('#but')
// const div = document.querySelector('#result')
// button.onclick = () => {
//     const request = new XMLHttpRequest()
//     request.open('GET', 'text.json')
//     request.setRequestHeader('Content-type', 'aplication/json')
//     request.send()

//     request.onload = () => {
//         let info = JSON.parse(request.response)
//         console.log(info);
//     }   
// }